async function getReply() {
  const prompt = document.getElementById('prompt').value;
  const response = await fetch('http://localhost:5000/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: prompt })
  });
  const data = await response.json();
  document.getElementById('response').innerText = data.reply || "Something went wrong.";
}

async function generateResume() {
  const name = document.getElementById('name').value;
  const skills = document.getElementById('skills').value;
  const prompt = `Generate a simple resume for ${name} with skills: ${skills}`;
  const response = await fetch('http://localhost:5000/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: prompt })
  });
  const data = await response.json();
  document.getElementById('resume-output').innerText = data.reply || "Something went wrong.";
}

async function sendMessage() {
  const userMessage = document.getElementById('user-input').value;
  const response = await fetch("http://localhost:5000/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: userMessage })
  });
  const data = await response.json();
  document.getElementById('chat-response').innerText = data.reply || "Something went wrong.";
}
