from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from dotenv import load_dotenv

# Try importing OpenAI, fallback to mock if not working
try:
    import openai
    use_openai = True
except ImportError:
    use_openai = False

load_dotenv()

app = Flask(__name__)
CORS(app)

openai_api_key = os.getenv("OPENAI_API_KEY")
if use_openai:
    openai.api_key = openai_api_key

@app.route('/api/chat', methods=['POST'])
def chat_with_ai():
    data = request.get_json()
    user_message = data.get("message", "")

    try:
        if use_openai and openai_api_key:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a career counselor helping students choose career paths."},
                    {"role": "user", "content": user_message}
                ]
            )
            ai_reply = response['choices'][0]['message']['content'].strip()
        else:
            # Mocked reply
            ai_reply = f"Mock response: You asked about '{user_message}', here’s a dummy career suggestion."

        return jsonify({"reply": ai_reply})
    except Exception as e:
        print("Error:", str(e))
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
